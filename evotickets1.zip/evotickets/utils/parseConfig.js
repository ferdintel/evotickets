// utils/parseConfig.js
import Parse from 'parse';

Parse.initialize(
  'AX1n5pkkAjVppAZMhl4YHEjHZM5Ul7YTAJaXmLhn',
  'VkoW3WNNDYQXin1uGWiq8KEQXhTJwMZ9I4LhvNbz'
);
Parse.serverURL = 'https://parseapi.back4app.com/';

export default Parse;
