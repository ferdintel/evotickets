// pages/index.js
import { useEffect } from 'react';
import Parse from '../utils/parseConfig';
import { useRouter } from 'next/router';

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    const redirectUser = async () => {
      const currentUser = Parse.User.current();
      if (currentUser) {
        const roleQuery = new Parse.Query(Parse.Role);
        roleQuery.equalTo('users', currentUser);
        const roles = await roleQuery.find();
        const userRoles = roles.map((role) => role.get('name'));
        if (userRoles.includes('Manager')) {
          router.push('/manager/dashboard');
        } else if (userRoles.includes('Seller')) {
          router.push('/seller/dashboard');
        } else if (userRoles.includes('Controller')) {
          router.push('/controller/scanner');
        } else {
          alert('Role not assigned. Please contact admin.');
          router.push('/login');
        }
      } else {
        router.push('/login');
      }
    };

    redirectUser();
  }, [router]);

  return null;
}
