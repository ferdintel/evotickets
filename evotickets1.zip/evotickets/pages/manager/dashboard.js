// pages/manager/dashboard.js
import { useEffect, useState } from 'react';
import Parse from '../../utils/parseConfig';
import withAuth from '../../utils/withAuth';
import QRCodeScanner from '../../components/QRCodeScanner';

function ManagerDashboard() {
  const [tickets, setTickets] = useState([]);
  const [scannedCode, setScannedCode] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [ticketDetails, setTicketDetails] = useState(null);

  useEffect(() => {
    const fetchTickets = async () => {
        const currentUser = Parse.User.current();
      
        // Get events associated with the user
        const eventsRelation = currentUser.relation('events');
        const eventsQuery = eventsRelation.query();
        const userEvents = await eventsQuery.find();
      
        const Ticket = Parse.Object.extend('Ticket');
        const query = new Parse.Query(Ticket);
        query.containedIn('event', userEvents);
        query.include('event');
        const results = await query.find();
        setTickets(results);
      };
      

    fetchTickets();
  }, []);

  const handleScan = async (code) => {
    setScannedCode(code);
    const Ticket = Parse.Object.extend('Ticket');
    const query = new Parse.Query(Ticket);
    query.equalTo('code', code);
    query.include('event');
    const ticket = await query.first();
    if (ticket) {
      const ticketEvent = ticket.get('event');
      const isAuthorized = userEvents.some(
        (event) => event.id === ticketEvent.id
      );
      if (isAuthorized) {
        setTicketDetails(ticket);
        setSelectedStatus(ticket.get('status'));
      } else {
        alert('You are not authorized to access this ticket.');
      }
    } else {
      alert('Ticket not found.');
    }
  };

  const updateStatus = async () => {
    if (ticketDetails && selectedStatus) {
      ticketDetails.set('status', selectedStatus);
      await ticketDetails.save();
      alert('Ticket status updated successfully.');
      setTicketDetails(null);
      setSelectedStatus('');
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl mb-4">Manager Dashboard</h1>

      <div className="mb-6">
        <h2 className="text-xl mb-2">Scan Ticket</h2>
        <QRCodeScanner onScan={handleScan} />
      </div>

      {ticketDetails && (
        <div className="mb-6">
          <h2 className="text-xl mb-2">Ticket Details</h2>
          <p>Code: {ticketDetails.get('code')}</p>
          <p>Event: {ticketDetails.get('event').get('name')}</p>
          <p>Current Status: {ticketDetails.get('status')}</p>
          <div className="mt-2">
            <label className="block mb-1">Update Status:</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="border p-2"
            >
              <option value="Valid">Valid</option>
              <option value="Active">Active</option>
              <option value="Used">Used</option>
              <option value="Invalid">Invalid</option>
            </select>
            <button
              onClick={updateStatus}
              className="bg-green-500 text-white p-2 ml-2"
            >
              Update
            </button>
          </div>
        </div>
      )}

      <div>
        <h2 className="text-xl mb-2">All Tickets</h2>
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="border p-2">Code</th>
              <th className="border p-2">Event</th>
              <th className="border p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td className="border p-2">{ticket.get('code')}</td>
                <td className="border p-2">
                  {ticket.get('event').get('name')}
                </td>
                <td className="border p-2">{ticket.get('status')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default withAuth(ManagerDashboard, ['Manager']);