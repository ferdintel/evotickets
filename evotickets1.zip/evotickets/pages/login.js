// pages/login.js
import { useState } from 'react';
import Parse from '../utils/parseConfig';
import { useRouter } from 'next/router';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      await Parse.User.logIn(username, password);
      const user = Parse.User.current();
      const role = await getUserRole(user);
      if (role === 'Manager') {
        router.push('/manager/dashboard');
      } else if (role === 'Seller') {
        router.push('/seller/dashboard');
      } else if (role === 'Controller') {
        router.push('/controller/scanner');
      } else {
        alert('Role not assigned. Please contact admin.');
      }
    } catch (error) {
      alert('Invalid username or password.');
      console.error('Error while logging in user', error);
    }
  };

  const getUserRole = async (user) => {
    const query = new Parse.Query(Parse.Role);
    query.equalTo('users', user);
    const roles = await query.find();
    return roles.length > 0 ? roles[0].get('name') : null;
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form
        className="bg-white p-6 rounded shadow-md"
        onSubmit={handleLogin}
      >
        <h2 className="text-2xl mb-4">Evotickets Login</h2>
        <input
          type="text"
          placeholder="Username"
          className="border p-2 w-full mb-4"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          className="border p-2 w-full mb-4"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button
          type="submit"
          className="bg-blue-500 text-white p-2 w-full"
        >
          Login
        </button>
        <p className="mt-4">
          Don't have an account? <a href="/signup" className="text-blue-500">Sign Up</a>
        </p>
      </form>
    </div>
  );
}
